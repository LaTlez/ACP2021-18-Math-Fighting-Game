﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimeBarScript : MonoBehaviour {

    public Transform filbar;
    public float currentTime;  // ตัวที่แสดงค่าเวลา
    public float delay = 0.1f;
    public static TimeBarScript instance;

	void Start () {

        currentTime = 1;
		
	}
    private void Awake()
    {
        MakeInstance();
    }

    void MakeInstance()
    {
        if (instance==null)
        {
            instance = this;
        }

    }
	
	
	void Update () {
        currentTime -= delay * Time.deltaTime;  // ลดค่าตัว currentime
        filbar.GetComponent<Image>().fillAmount = currentTime;
        if (currentTime< 0f)
        {
            Application.LoadLevel("Home");
        }
		
	}
}
