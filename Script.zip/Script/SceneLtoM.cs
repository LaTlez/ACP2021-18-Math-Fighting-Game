﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SceneLtoM : MonoBehaviour
{
    public static int min, max;
    public  int Plus =1 ,dif = 2 ,multipel = 3,division = 4;

    public void changeScene(int mode)
    {
        if (mode == 1)
        {
            min = 2;
            max = 10;


        } else if (mode == 2)
        {
            min = 10;
            max = 100;


        } else
        {
            min = 100;
            max = 1000;

        }
        check();
        //Application.LoadLevel("MainScene");
        //Application.LoadLevel("MainScene");
    }

    void check() {

        if (Plus == SModetoL.Conducter)
        {
            Application.LoadLevel("MainScene");
        }
        else if (dif == SModetoL.Conducter)
        {
            Application.LoadLevel("MainSubtract");


        }
        else if ( multipel == SModetoL.Conducter)
        {
            Application.LoadLevel("MainMul");

        }
        else
        {
            Application.LoadLevel("MainDivision");
        }

        
        
    }
}

