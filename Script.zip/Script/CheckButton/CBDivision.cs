﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CBDivision : MonoBehaviour
{
    private AudioSource au;
    public AudioClip[] sound;
    public Image background;


    // Use this for initialization
    void Start()
    {
        au = GetComponent<AudioSource>();

    }



    public void checkTagButton()
    {
        if (gameObject.CompareTag(ConDivision.instanceDivision.tagBtnDivison))
        {
            ConDivision.instanceDivision.score++;
            ConDivision.instanceDivision.AdditionMethod(); // เปลี่ยนโจทย์
            //TimeBarScript.instance.currentTime = 1;
            au.PlayOneShot(sound[0]);
        }
        else
        {
            //StartCoroutine(ChangeColor());
            ConDivision.instanceDivision.score--;
            ConDivision.instanceDivision.AdditionMethod(); // เปลี่ยนโจทย์
            Debug.Log(ConDivision.instanceDivision.score);
            TimeBarScript.instance.currentTime -= 0.05f;

            //Countdown.instance.timeStart -= 1.5;
            au.PlayOneShot(sound[1]);

        }
    }
    
}

