﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CBMultiple : MonoBehaviour
{
    private AudioSource au;
    public AudioClip[] sound;
    public Image background;


    // Use this for initialization
    void Start()
    {
        au = GetComponent<AudioSource>();

    }



    public void checkTagButton()
    {
        if (gameObject.CompareTag(ConMultiple.instanceMul.tagBtnDifferennt))
        {
            ConMultiple.instanceMul.score++;
            ConMultiple.instanceMul.AdditionMethod(); // เปลี่ยนโจทย์
            //TimeBarScript.instance.currentTime = 1;
            au.PlayOneShot(sound[0]);
        }
        else
        {
            //StartCoroutine(ChangeColor());
            ConMultiple.instanceMul.score--;
            ConMultiple.instanceMul.AdditionMethod(); // เปลี่ยนโจทย์
            Debug.Log(ConMultiple.instanceMul.score);
            TimeBarScript.instance.currentTime -= 0.05f;

            //Countdown.instance.timeStart -= 1.5;
            au.PlayOneShot(sound[1]);

        }
    }
    //IEnumerator ChangeColor()
    //{
    //    // พื้นหลังสีแดง RGB
    //    background.color = new Color32(221, 127, 127, 255);
    //    yield return new WaitForSeconds(0.05f);
    //    background.color = new Color32(225, 255, 255, 255);
    //}
}