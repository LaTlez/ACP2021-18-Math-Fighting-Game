﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class CBDiff : MonoBehaviour {
    private AudioSource au;
    public AudioClip[] sound;
    public  Image background;
    

    // Use this for initialization
    void Start () {
        au = GetComponent<AudioSource>();
		
	}
	
	
	
    public void checkTagButton()
    {
        if (gameObject.CompareTag(ConDif.instanceDif.tagBtnDif))
        {
            ConDif.instanceDif.score++;
            ConDif.instanceDif.AdditionMethod(); // เปลี่ยนโจทย์
            //TimeBarScript.instance.currentTime = 1;
            au.PlayOneShot(sound[0]);
        }
        else
        {
            //StartCoroutine(ChangeColor());
            ConDif.instanceDif.score--;
            ConDif.instanceDif.AdditionMethod(); // เปลี่ยนโจทย์
            Debug.Log(ConDif.instanceDif.score);
            TimeBarScript.instance.currentTime -= 0.05f;

            //Countdown.instance.timeStart -= 1.5;
            au.PlayOneShot(sound[1]);

        }
    }
    //IEnumerator ChangeColor()
    //{
    //    // พื้นหลังสีแดง RGB
    //    background.color = new Color32(221,127,127,255);
    //    yield return new WaitForSeconds(0.05f);
    //    background.color = new Color32(225, 255, 255, 255);
    //}
}
