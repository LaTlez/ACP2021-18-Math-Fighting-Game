﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConMultiple : MonoBehaviour
{


    private float a, b;
    private float answer;
    public Text valueA, valueB, scoretxt;
    private float localofAnswer; // เก็บตำแหน่งคำตอบที่ถูกต้อง
    public int score;
    public GameObject[] choiceBtn; // จำนวน choice 4 ตัว
    public string tagBtnDifferennt;    // เป็นตัวที่บ่งบอก choice ไหน choice ไหนผิด
    public static ConMultiple instanceMul;
    public int r1 = 100, r2 = 1000;

    private void Awake()
    {
        MakeInstance();
    }
    void MakeInstance()
    {
        if (instanceMul == null)
        {
            instanceMul = this;
        }
    }

    void Start()
    {
        //Debug.Log("Natcha.su");
        r1 = SceneLtoM.min;
        r2 = SceneLtoM.max;
        AdditionMethod();

    }


    void Update()
    {
        tagBtnDifferennt = localofAnswer.ToString();
        scoretxt.text = "" + score;


    }
    // สร้างฟังก์ชั่นในการสุ่มตัวเลขและนำตัวเลขมาบวกกัน
    public void AdditionMethod()
    {
        a = Random.Range(r1, r2);   // random ตั้งแต่ 0-9
        b = Random.Range(r1, r2);
        valueA.text = "" + a;
        valueB.text = "" + b;
        answer = a * b;


        // สุ่มตำแหน่งที่จะใส่คำตอบที่ถูกต้องลงไป
        localofAnswer = Random.Range(0, choiceBtn.Length); // ตำแหน่งของปุ่มคำตอบที่ถูก

        // ลูป choice
        for (int i = 0; i < choiceBtn.Length; i++)
        {
            // เพื้อเปลี่ยนตัวเลขด้านใน
            // ตำแหน่งตรงกับ localofAnswer
            if (i == localofAnswer)
            {
                // แปะคำตอบที่ถูกต้องลงใน Text ของปุ่ม
                choiceBtn[i].GetComponentInChildren<Text>().text = "" + answer;
            }
            else
            {
                // คำตอบที่ผิดที่จะแสดงในปุ่ม
                choiceBtn[i].GetComponentInChildren<Text>().text = "" + (Random.Range(r1, r2*r2));

                double randomchoice = double.Parse(choiceBtn[i].GetComponentInChildren<Text>().text);
                int j = 0;
                while (choiceBtn[i].GetComponentInChildren<Text>().text == "" + answer || randomchoice < answer * 0.7 || randomchoice > answer * 1.3 )
                {
                    
                    //    choiceBtn[i].GetComponentInChildren<Text>().text = "" + Random.Range(1, 18);
                    choiceBtn[i].GetComponentInChildren<Text>().text = "" + (Random.Range(r1, r2 * r2));
                    randomchoice = double.Parse(choiceBtn[i].GetComponentInChildren<Text>().text);
                }
            }



        }
    }

}

