﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SModetoL : MonoBehaviour {
    public  static int Conducter;

    public void changeScene(int con)
    {
        Conducter = con;
        

        Application.LoadLevel("Level");
    }
}
