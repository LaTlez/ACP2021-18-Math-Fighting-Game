using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CheckButton : MonoBehaviour
{

    // private AudioSource au;
    // public AudioClip[] sound;
    // public Image background;
    public static int punchCheck = 0;
    public static int mode = 0;

    public void CheckTagButton()
    {
        if (gameObject.CompareTag(EasyPlusController.instance.tagBtn))
        {
            mode = 1;
            // EasyPlusController.instance.score++;
            
            EasyPlusController.instance.AdditionMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1.5f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            mode = 1;
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;
            
            EasyPlusController.instance.AdditionMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1.5f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }

    public void CheckTagButtonNormal()
    {
        if (gameObject.CompareTag(EasyPlusController.instance.tagBtn))
        {
            mode = 2;
            // EasyPlusController.instance.score++;

            EasyPlusController.instance.AdditionMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            mode = 2;
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;

            EasyPlusController.instance.AdditionMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }

    public void CheckTagButtonHard()
    {
        if (gameObject.CompareTag(EasyPlusController.instance.tagBtn))
        {
            mode = 3;
            // EasyPlusController.instance.score++;

            EasyPlusController.instance.AdditionMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 0.75f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            mode = 3;
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;

            EasyPlusController.instance.AdditionMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 0.75f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }
}
