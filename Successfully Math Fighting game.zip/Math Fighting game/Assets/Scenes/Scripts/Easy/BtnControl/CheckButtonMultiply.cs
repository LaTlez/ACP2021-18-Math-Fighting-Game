using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CheckButtonMultiply : MonoBehaviour
{
    public static int punchCheck = 0;

    public void CheckTagButton()
    {
        if (gameObject.CompareTag(EasyMultiplyController.instanceMultiply.tagBtnMultiply))
        {
            CheckButton.mode = 1;
            // EasyPlusController.instance.score++;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1.5f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            CheckButton.mode = 1;
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1.5f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }
    public void CheckTagButtonNormal()
    {
        if (gameObject.CompareTag(EasyMultiplyController.instanceMultiply.tagBtnMultiply))
        {
            CheckButton.mode = 2;
            // EasyPlusController.instance.score++;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            CheckButton.mode = 2;
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }
    public void CheckTagButtonHard()
    {
        if (gameObject.CompareTag(EasyMultiplyController.instanceMultiply.tagBtnMultiply))
        {
            CheckButton.mode = 3;
            // EasyPlusController.instance.score++;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 0.75f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            CheckButton.mode = 3;
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 0.75f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }
}
