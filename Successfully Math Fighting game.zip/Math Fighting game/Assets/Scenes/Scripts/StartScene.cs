using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartScene : MonoBehaviour
{
    public void StartGame()
    {
        SceneManager.LoadScene("LevelScene");
    }

    public void QuitGame()
    {
        Debug.Log("Quit!");
        Application.Quit();
    }

    public void Easy()
    {
        SceneManager.LoadScene("OperatorEasyScene");
    }
    public void EasyPlus()
    {
        SceneManager.LoadScene("EasyPlusScene");
    }
    public void EasyMinus()
    {
        SceneManager.LoadScene("EasyMinusScene");
    }
    public void EasyMultiply()
    {
        SceneManager.LoadScene("EasyMultiplyScene");
    }
    public void EasyDivision()
    {
        SceneManager.LoadScene("EasyDivisionScene");
    }

    public void Normal()
    {
        SceneManager.LoadScene("OperatorNormalScene");
    }
    public void NormalPlus()
    {
        SceneManager.LoadScene("NormalPlusScene");
    }
    public void NormalMinus()
    {
        SceneManager.LoadScene("NormalMinusScene");
    }
    public void NormalMultiply()
    {
        SceneManager.LoadScene("NormalMultiplyScene");
    }
    public void NormalDivision()
    {
        SceneManager.LoadScene("NormalDivisionScene");
    }

    public void Hard()
    {
        SceneManager.LoadScene("OperatorHardScene");
    }
    public void HardPlus()
    {
        SceneManager.LoadScene("HardPlusScene");
    }
    public void HardMinus()
    {
        SceneManager.LoadScene("HardMinusScene");
    }
    public void HardMultiply()
    {
        SceneManager.LoadScene("HardMultiplyScene");
    }
    public void HardDivision()
    {
        SceneManager.LoadScene("HardDivisionScene");
    }

    public void BackBtnForLevelScene()
    {
        SceneManager.LoadScene("StartScene");
    }

    public void BackBtnForOperatorScene()
    {
        SceneManager.LoadScene("LevelScene");
    }
}
