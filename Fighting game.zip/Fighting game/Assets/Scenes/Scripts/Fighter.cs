using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fighter : MonoBehaviour
{
    // Player 1 or 2
    public enum PlayerType
    {
        Player1, Player2
    };

    public static float MAX_HEALTH = 1000f; // start HP
    public float health = MAX_HEALTH; // HP at a time
    public string fighterName; // Player Rename
    public Fighter oponent; // Reference Object (using OOP)
    public bool enable; // Player State 
    public PlayerType player; 
    public FighterStates currentState = FighterStates.IDLE; // Start is IDLE

    public Rigidbody mybody;
    protected Animator animator;
    private AudioSource audio;

    void Start()
    {
        mybody = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
        audio = GetComponent<AudioSource>();
    }

    void Update()
    {

        animator.SetFloat("HEALTH", healthPercent);
        if (oponent != null)
        {
            animator.SetFloat("OPPONENT", oponent.healthPercent);
        }
        else
        {
            animator.SetFloat("OPPONENT", 1);
        }

        if (health <= 0 && currentState != FighterStates.DEAD)
        {
            animator.SetTrigger("DEAD");
        }

        if (enable)
        {
            if (player == PlayerType.Player1)
            {
                ControlPlayer1();
            }
            else
            {
                ControlPlayer2();
            }
        }
    }

    public void ControlPlayer1()
    {
        // Horizontal
        // User press <Right Arrow> or <D>
        if (Input.GetAxis("Horizontal1") > 0.1)
        {
            animator.SetBool("WALK", true);
        } else
        {
            animator.SetBool("WALK", false);
        }
        // User press <Left Arrow> or <A>
        if (Input.GetAxis("Horizontal1") < -0.1)
        {
            animator.SetBool("WALK_BACK", true);
        }
        else
        {
            animator.SetBool("WALK_BACK", false);
        }
        // Vertical
        // User press <Down Arrow> or <S>
        if (Input.GetAxis("Vertical1") < -0.1)
        {
            animator.SetBool("SIT", true);
        }
        else
        {
            animator.SetBool("SIT", false);
        }

        // User press <B> to jump
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            animator.SetTrigger("JUMP");
        }
        // User press <N> to punch
        if (Input.GetKeyDown(KeyCode.N)) 
        {
            animator.SetTrigger("PUNCH");
        }
        // User press <M> to kick
        if (Input.GetKeyDown(KeyCode.M))
        {
            animator.SetTrigger("KICK");
        }
    }

    public void ControlPlayer2()
    {
        if (Input.GetAxis("Horizontal2") > 0.1)
        {
            animator.SetBool("WALK", true);
        }
        else
        {
            animator.SetBool("WALK", false);
        }

        if (Input.GetAxis("Horizontal2") < -0.1)
        {
            animator.SetBool("WALK_BACK", true);
        }
        else
        {
            animator.SetBool("WALK_BACK", false);
        }

        if (Input.GetAxis("Vertical2") < -0.1)
        {
            animator.SetBool("SIT", true);
        }
        else
        {
            animator.SetBool("SIT", false);
        }
        if (Input.GetAxis("Vertical2") < -0.1)
        {
            animator.SetBool("SIT", true);
        }
        if (Input.GetKeyDown(KeyCode.G))
        {
            animator.SetTrigger("JUMP");
        }
        if (Input.GetKeyDown(KeyCode.H))
        {
            animator.SetTrigger("PUNCH");
        }
        if (Input.GetKeyDown(KeyCode.J))
        {
            animator.SetTrigger("KICK");
        }
    }

    public void playsound(AudioClip sound)
    {
        SoundManager.playsound(sound, audio);
    }

    public bool defending
    {
        get
        {
            return currentState == FighterStates.DEFEND ||
                currentState == FighterStates.TAKE_HIT_DEFEND;
        }
    }

    public bool attacking
    {
        get
        {
            return currentState == FighterStates.ATTACK;
        }
    }

    // �ѧ��ѹŴ���ʹ
    public virtual void hurt(float damage)
    {
        if (defending)
        {
            damage *= 0.2f;
        }
        if (health >= damage)
        {
            health -= damage;
        }
        else
        {
            health = 0;
        }

        if (health > 0)
        {
            animator.SetTrigger("TAKE_HIT");
        }
    }

    // Get HP 1000/1000 => 950/1000
    public float healthPercent
    {
        get
        {
            return health / MAX_HEALTH;
        }
    }

    public Rigidbody body
    {
        get
        {
            return this.mybody;
        }
    }
}