using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MathController : MonoBehaviour
{
    private float a, b; // �ǡ�Ţ
    private float answer; // ���Ѿ��ǡ�Ţ
    public Text valueA, valueB, scoreTxt;
    private float localofAnswer; //�纵��˹觤ӵͺ���١
    public int score;
    public GameObject[] choiceBtn; //�ӹǹ choice 4 ���
    public string tagBtn; // choice �˹�١ choice �˹�Դ
    public static MathController instance;

    private void Awake()
    {
        MakeInstance();
    }

    // Start is called before the first frame update
    void Start()
    {
        AdditionMethod();
    }

    // Update is called once per frame
    void Update()
    {
        tagBtn = localofAnswer.ToString();
        scoreTxt.text = "" + score;
    }

    void MakeInstance()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    // ���ҧ�ѧ��ѹ㹡�������Ţ��й��Ţ�Һǡ�ѹ
    public void AdditionMethod()
    {
        a = Random.Range(0, 21); //Min, Max
        b = Random.Range(0, 21);

        valueA.text = "" + a;
        valueB.text = "" + b;

        answer = a + b;

        //�������� choice ���͡�˹� choice ���١
        localofAnswer = Random.Range(0, choiceBtn.Length); // ���˹觷��١

        for (int i = 0;i < choiceBtn.Length;i++)
        {
            // �ٻ��������¹����Ţ��ҹ�
            // ��Ҥӵͺ�ç�ѺlocalAnswer
            if (i == localofAnswer)
            {
                // �������١
                choiceBtn[i].GetComponentInChildren<Text>().text = "" + answer;
            }
            else
            {
                // �������Դ
                choiceBtn[i].GetComponentInChildren<Text>().text = "" + Random.Range(1, 41);

                while (choiceBtn[i].GetComponentInChildren<Text>().text == "" + answer)
                {
                    choiceBtn[i].GetComponentInChildren<Text>().text = "" + Random.Range(1, 41);
                }
            }
        }
    }
}
