using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TimeBarScript : MonoBehaviour
{
    public Transform fillbar;
    public float currentTime, delayTime = 0.5f;
    public static TimeBarScript instance;

    // Start is called before the first frame update
    void Start()
    {
        currentTime = 1;
    }

    private void Awake()
    {
        MakeInstance();
    }

    void MakeInstance()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    // Update is called once per frame
    void Update()
    {
        currentTime -= delayTime * Time.deltaTime;
        fillbar.GetComponent<Image>().fillAmount = currentTime;

        if (currentTime < 0.1f)
        {
            SceneManager.LoadScene("Home");
        }
    }
}