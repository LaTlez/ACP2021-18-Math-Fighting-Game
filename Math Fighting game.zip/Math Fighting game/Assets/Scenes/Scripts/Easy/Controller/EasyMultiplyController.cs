using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EasyMultiplyController : MonoBehaviour
{
    private float a, b; // �ǡ�Ţ
    private float answer; // ���Ѿ��ǡ�Ţ
    public Text valueA, valueB;
    // public Text playerPunch;
    // public int playerScore;
    private float localofAnswer; //�纵��˹觤ӵͺ���١
    public GameObject[] choiceBtn; //�ӹǹ choice 4 ���
    public string tagBtnMultiply; // choice �˹�١ choice �˹�Դ
    public static EasyMultiplyController instanceMultiply;

    private void Awake()
    {
        MakeInstance();
    }

    // Start is called before the first frame update
    void Start()
    {
        MultiplyMethod();
    }

    // Update is called once per frame
    void Update()
    {
        tagBtnMultiply = localofAnswer.ToString();
        // playerPunch.text = "" + playerScore;
    }

    void MakeInstance()
    {
        if (instanceMultiply == null)
        {
            instanceMultiply = this;
        }
    }

    // ���ҧ�ѧ��ѹ㹡�������Ţ��й��Ţ�Һǡ�ѹ
    public void MultiplyMethod()
    {
        a = Random.Range(1, 13); //Min, Max
        b = Random.Range(1, 13);

        valueA.text = "" + a;
        valueB.text = "" + b;

        answer = a * b;

        //�������� choice ���͡�˹� choice ���١
        localofAnswer = Random.Range(0, choiceBtn.Length); // ���˹觷��١

        for (int i = 0; i < choiceBtn.Length; i++)
        {
            // �ٻ��������¹����Ţ��ҹ�
            // ��Ҥӵͺ�ç�ѺlocalAnswer
            if (i == localofAnswer)
            {
                // �������١
                choiceBtn[i].GetComponentInChildren<Text>().text = "" + answer;
            }
            else
            {
                // �������Դ
                choiceBtn[i].GetComponentInChildren<Text>().text = "" + Random.Range(1, 144);

                while (choiceBtn[i].GetComponentInChildren<Text>().text == "" + answer)
                {
                    choiceBtn[i].GetComponentInChildren<Text>().text = "" + Random.Range(1, 144);
                }
            }
        }
    }
}
