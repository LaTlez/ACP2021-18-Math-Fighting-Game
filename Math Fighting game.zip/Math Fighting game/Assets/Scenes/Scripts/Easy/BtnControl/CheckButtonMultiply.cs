using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CheckButtonMultiply : MonoBehaviour
{
    public static int punchCheck = 0;

    public void CheckTagButton()
    {
        if (gameObject.CompareTag(EasyMultiplyController.instanceMultiply.tagBtnMultiply))
        {
            // EasyPlusController.instance.score++;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1.5f; //Reset ����
            // au.PlayOneShot(sound[0]);
            punchCheck = 1;
        }
        else
        {
            // StartCoroutine(ChangeColor());
            // EasyPlusController.instance.score--;

            EasyMultiplyController.instanceMultiply.MultiplyMethod(); // ����¹⨷��
            TimeBarScript.instance.currentTime = 1.5f; //Reset ����
            // au.PlayOneShot(sound[1]);
            punchCheck = -1;
        }
    }
}
