using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TimeBarScript : MonoBehaviour
{
    public Transform fillbar;
    public float currentTime;
    public float delayTime = 0.25f;
    public static TimeBarScript instance;
    public bool nextquestion = false;


    // Start is called before the first frame update
    void Start()
    {
        currentTime = 1.5f;
        if (currentTime < 0.1f)
        {
            nextquestion = true;
        }
        nextquestion = true;
        if (CheckButton.mode.Equals(1) && nextquestion)
        {
            currentTime = 1.5f;
        }
        if (CheckButton.mode.Equals(1) && nextquestion)
        {
            currentTime = 1f;
        }
        if (CheckButton.mode.Equals(1) && nextquestion)
        {
            currentTime = 0.75f;
        }
    }

    private void Awake()
    {
        MakeInstance();
    }

    void MakeInstance()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    // Update is called once per frame
    void Update()
    {
        currentTime -= delayTime * Time.deltaTime;
        fillbar.GetComponent<Image>().fillAmount = currentTime;

        if (CheckButton.mode.Equals(1))
        {
            if (currentTime < 0.1f)
            {
                CheckButton.punchCheck = -1;
                currentTime = 1.5f;
            }
        }
        if (CheckButton.mode.Equals(2))
        {
            if (currentTime < 0.1f)
            {
                CheckButton.punchCheck = -1;
                currentTime = 1f;
            }
        }
        if (CheckButton.mode.Equals(3))
        {
            if (currentTime < 0.1f)
            {
                CheckButton.punchCheck = -1;
                currentTime = 0.75f;
            }
        }
    }
}