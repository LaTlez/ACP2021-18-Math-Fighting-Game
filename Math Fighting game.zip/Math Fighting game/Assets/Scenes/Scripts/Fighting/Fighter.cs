using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Fighter : MonoBehaviour
{
    // Player 1 or 2
    public enum PlayerType
    {
        Player1, Player2
    };

    public static float MAX_HEALTH = 1000f; // start HP
    public float health = MAX_HEALTH; // HP at a time
    public string fighterName; // Player Rename
    public Fighter oponent; // Reference Object (using OOP)
    public bool enable; // Player State 
    public PlayerType player; 
    public FighterStates currentState = FighterStates.IDLE; // Start is IDLE

    public Rigidbody mybody;
    protected Animator animator;
    private AudioSource audio;
    // public int punchCheck = 0;

    void Start()
    {
        mybody = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
        audio = GetComponent<AudioSource>();
    }

    void Update()
    {

        animator.SetFloat("HEALTH", healthPercent);
        if (oponent != null)
        {
            animator.SetFloat("OPPONENT", oponent.healthPercent);
        }
        else
        {
            animator.SetFloat("OPPONENT", 1);
        }

        if (health <= 0 && currentState != FighterStates.DEAD)
        {
            animator.SetTrigger("DEAD");
        }

        if (currentState == FighterStates.DEAD)
        {
            if (player == PlayerType.Player1)
            {
                SceneManager.LoadScene("LoseScoreBoard");
            }
            else
            {
                SceneManager.LoadScene("WinScoreBoard");
            }
        }

        if (enable)
         {
            if (player == PlayerType.Player1)
            {
                if (CheckButton.punchCheck.Equals(1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButton.punchCheck = 0;
                }
                if (CheckButtonMinus.punchCheck.Equals(1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButtonMinus.punchCheck = 0;
                }
                if (CheckButtonMultiply.punchCheck.Equals(1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButtonMultiply.punchCheck = 0;
                }
                if (CheckButtonDivision.punchCheck.Equals(1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButtonDivision.punchCheck = 0;
                }
            }
            else
            {
                if (CheckButton.punchCheck.Equals(-1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButton.punchCheck = 0;
                }
                if (CheckButtonMinus.punchCheck.Equals(-1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButtonMinus.punchCheck = 0;
                }
                if (CheckButtonMultiply.punchCheck.Equals(-1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButtonMultiply.punchCheck = 0;
                }
                if (CheckButtonDivision.punchCheck.Equals(-1))
                {
                    animator.SetTrigger("PUNCH");
                    CheckButtonDivision.punchCheck = 0;
                }
            }
         }
    }

    public void playsound(AudioClip sound)
    {
        SoundManager.playsound(sound, audio);
    }

    public bool attacking
    {
        get
        {
            return currentState == FighterStates.ATTACK;
        }
    }

    // �ѧ��ѹŴ���ʹ
    public virtual void hurt(float damage)
    {
        if (health >= damage)
        {
            health -= damage;
        }
        else
        {
            health = 0;
        }

        if (health > 0)
        {
            animator.SetTrigger("TAKE_HIT");
        }
    }

    // Get HP 1000/1000 => 950/1000
    public float healthPercent
    {
        get
        {
            return health / MAX_HEALTH;
        }
    }

    public Rigidbody body
    {
        get
        {
            return this.mybody;
        }
    }

}