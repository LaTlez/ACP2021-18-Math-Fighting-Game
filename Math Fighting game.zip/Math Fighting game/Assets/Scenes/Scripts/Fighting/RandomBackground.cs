using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RandomBackground : MonoBehaviour
{
    int ran = 0;
    void Start()
    {
        Animator anim = GetComponent<Animator>();
        ran = UnityEngine.Random.Range(0, 4);
        anim.SetInteger("STATE", ran);
    }
}
